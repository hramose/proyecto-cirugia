<?php
/* @var $this VentasController */
/* @var $model Ventas */


?>
<?php 
?>
<h1>No hay Egresos</h1>
