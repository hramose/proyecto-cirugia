<?php
/* @var $this VentasController */
/* @var $model Ventas */


?>
<?php 
?>
<h1>No hay Pagos Pendientes</h1>
