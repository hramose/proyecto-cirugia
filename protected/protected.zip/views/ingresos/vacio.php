<?php
/* @var $this VentasController */
/* @var $model Ventas */


?>
<?php 
?>
<h1>No hay Ingresos</h1>
