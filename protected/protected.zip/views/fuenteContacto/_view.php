<?php
/* @var $this FuenteContactoController */
/* @var $data FuenteContacto */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('fuente')); ?>:</b>
	<?php echo CHtml::encode($data->fuente); ?>
	<br />


</div>