"Boxify" One Page Website Template by Peter Finlan for Codrops

Demo: http://tympanus.net/Freebies/Boxify/
Download and article: http://tympanus.net/codrops/?p=22554

Use it freely but please do not redistribute or sell.
Read more here: http://tympanus.net/codrops/licensing/

Enjoy!